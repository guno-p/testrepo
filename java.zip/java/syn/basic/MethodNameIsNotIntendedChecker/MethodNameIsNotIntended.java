package basic;

public class MethodNameIsNotIntended {
    public String tostring() { // @violation
        return "abc";
    }
}