package test2;

public class Parent {
    public void methodWithComplexName(int x, double y) {

    }
}
