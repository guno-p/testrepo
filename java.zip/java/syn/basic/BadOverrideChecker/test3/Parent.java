package test3;

import one.Empty;

public class Parent {
    public void method(Empty[] e) {

    }
}
