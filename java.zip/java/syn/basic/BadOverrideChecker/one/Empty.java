package one;

public class Empty {

}
