package two;

public class Empty {

}
