package test4;

import one.Empty;

public class Parent {
    public int[] method(String[] a, int b, Empty[] c) {
        return new int[b];
    }
}
