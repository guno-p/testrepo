//UNSAFE_JACKSON_DESERIALIZATION
package security;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.codehaus.jackson.map.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

public class UnsafeJacksonDeserialization_TestCase {
    
    @JsonTypeInfo(use = Id.CLASS, include=As.WRAPPER_OBJECT) /* BUG */
    abstract class PhoneNumber {
    }

    @JsonTypeInfo(use = Id.MINIMAL_CLASS) /* BUG */
    abstract class PhoneNumber2 {
    }

    @JsonTypeInfo(use = Id.NAME) /* SAFE */
    abstract class PhoneNumber3 {
    }

    public void mapperTest() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enableDefaultTyping(); /* BUG */
    }

}