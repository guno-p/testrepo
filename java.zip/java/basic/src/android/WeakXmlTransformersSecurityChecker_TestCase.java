//WEAK_XML_TRANSFORMERS_SECURITY
package security;

import javax.servlet.http.HttpServletRequest;
import java.util.Hashtable;
import java.xml.transform;

public class WeakXmlTransformersSecurityChecker_TestCase {

    public void test() {
        //...        
        Transformer transformer = TransformerFactory.newInstance().newTransformer();    /* Bug */
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer2 = factory.newTransformer();   /* Bug */

        TransformerFactory factory2 = TransformerFactory.newInstance();
        factory2.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory2.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
        Transformer transformer3 = factory2.newTransformer();    /* Safe */
        //...
    }

}