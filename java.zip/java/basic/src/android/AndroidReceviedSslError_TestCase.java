package android;

public class AndroidReceviedSslError {

    @Override
    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
        super.onReceivedSslError(view, handler, error);
        handler.cancel();
        handler.proceed();  /* BUG */
    }


    @Override
    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
        if (DISABLE_SSL_CHECK_FOR_TESTING) {
            handler.proceed();  /* SAFE */
        } else {
            super.onReceivedSslError(view, handler, error);
            sendErrorToListener(new FacebookDialogException(null, ERROR_FAILED_SSL_HANDSHAKE, null));
            handler.cancel();   /* SAFE */
            WebDialog.this.dismiss();
        }
    }
}