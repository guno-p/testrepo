//WEAK_SERVER_CERTIFICATES
package security;

import javax.net.ssl.X509TrustManager;
import java.security.cert;

public  class WeakServerCertificatesChecker_TestCase implements X509TrustManager {

    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {  /* BUG */
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {  /* BUG */
        try {
            LOG.log(Level.SEVERE, ERROR_MESSAGE);
        } catch(Exception e) {
            throw Exception;
        }
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return null;
    }
}