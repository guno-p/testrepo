//BAD_RETURN_IN_IF_STATEMENT
package cc;

public class BadReturnInIfStatementCheckerTest{

    public boolean func(boolean b) {
        if(b) {
            return true;    /* BUG */
        } else {
            return false;   /* BUG */
        }
    }

    public int func(int i) {
        if(i == 1) {
            return 4;   /* BUG */
        } else if(i == 2) {
            return 6;   /* BUG */
        } else {
            return 0;   /* BUG */
        }
    }

    public int func(int i) {
        if(i == 1) {
            return 4;   /* BUG */
        }
        return 0;
    }

    public int func(int i) {
        if(i == 1)
            return 4;   /* BUG */
        else
            return 0;   /* BUG */

    }

    public int func(int i) {
        if(i == 1) {
            i = 4;
            return i;
        } else {
            i = 6;
            return i;
        }

    }
}