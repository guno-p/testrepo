//IMPROPER_RETURN_STATEMENT
package cc;

public class ImproperReturnStatement {

    public int func(boolean condition, int intX, int intY) {
        if(condition) {
            return intX;    /* SAFE */
        } else if(intY == 1){
            return (intY > 0 ? intY : 0); /* SAFE */
        } else {
            return 1;   /* SAFE */
        }

        if(intX == 0) {
            return (intX);  /* BUG */
        } else if(intY == 0){
            return (test());    /* BUG */
        } else {
            return test();  /* SAFE */
        }

        return intY > 0 ? intY : 0; /* BUG */
    }

    public int test() {
        return (1); /* BUG */
    }

}
