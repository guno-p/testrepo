//EMPTY_WHILE_STATEMENT
package cc;

public class EmptyWhileStatement_TestCase {
    public void function() {
        while (true) {
            int a = 0;
        }

        while (true) {  /* BUG */

        }

        while (true) {}  /* BUG */

        while (true);   /* SAFE */
    }

}