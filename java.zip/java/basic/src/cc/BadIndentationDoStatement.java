// Checker: BAD_INDENTATION.DO_STATEMENT
package cc;

class BadIndentationDoStatement {
	public void test(){
		do {				/* Safe */
			do{				/* Bug */
				do
				{

	 			}while(1);	/* Bug */
			} while(1);
	} while(1);

		do
		{

		}  while(1);

		do {					/* Safe */

		}while(1);	/* Bug */

		do{					/* Bug */

		}	while(1);
	}
}