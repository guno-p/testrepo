//BAD_WHITESPACE.FOR_STATEMENT
package cc;

public class BadWhitespaceForStatement {
    public void func() {
        int i,j;

        for(i=0; i<10; i++) { /* BUG */
            // Do something ...
        }

        for (i=0;i<10; i++) { /* BUG */
            // Do something ...
        }

        for (i=0; i<10;i++) { /* BUG */
            // Do something ...
        }

        for (i=0, j=0;i<10;) { /* BUG */
            // Do something ...
        }

        for (i=0;;i++) { /* BUG */
            // Do something ...
        }

        for (i=0; i<10; i++) { /* SAFE */
            // Do something ...
        }
    }
}