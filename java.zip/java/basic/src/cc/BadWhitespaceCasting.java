//BAD_WHITESPACE.CASTING
package cc;

public class BadWhitespaceCasting {
    public void byteFunc(byte b) {
        // Do something ...
    }

    public void func(int a) {
        byte b;
        b = (byte)/* commnet */a; 	/* Safe */
        b = (byte) a;				/* BUG */
        b = (byte )a;				/* BUG if check inner space option is true */
        b = ( byte)a;				/* BUG if check inner space option is true */
        b = ( byte )a;				/* BUG if check inner space option is true */
        
        byteFunc((byte)a); 	/* Safe */
        byteFunc((byte) a);	/* BUG */
        byteFunc(( byte)a);	/* BUG if check inner space option is true */
        byteFunc((byte )a);	/* BUG if check inner space option is true */
        byteFunc(( byte )a);	/* BUG if check inner space option is true */
    }
}
