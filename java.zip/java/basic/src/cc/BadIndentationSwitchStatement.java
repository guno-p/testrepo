//BAD_INDENTATION.SWITCH_STATEMENT
package cc;

class BadIndentationSwitchStatement {
	public void make(){
		switch (
				a) {
		case 1:					/* Bug */
			a= 2;
			break;
		default:
			break;
		}
		
		switch (a) {				/* Safe */
			case 1:					/* Bug */
			a= 2;
			break;
		default:
			break;
		}
		
		switch (a) {				/* Safe */
		
		case 1:					/* Bug*/
			a= 2;
			break;
		default:
			break;
		}
	}
}