//BAD_COMPOUND_STATEMENT.CURLY_BRACE
package cc;

public class BadCompoundStatementCurlyBrace
{ /* BUG */
    public void func()
    {                                       /* BUG */
        int i,j;

        for(i=0; i<10; i++)
        {                   /* BUG */
            // Do something ...
        }
    }

    public void func2() {
        // Do something ...
    }

    public void func3() {
        // Do something ...
       }
    public void func4() {
        while (true)
        {
            // Do something ...
        }
        switch (a)
        {
        case 1:
            a= 2;
            break;
        default:
            break;
        }
    }

    public void func5() {

        /* safe */
        try {

        } catch (Exception e) {

        } finally {

        }


        try{    /* bug */

        }catch (Exception e) {  /* bug */

        }finally {  /* bug */

        }


        try {

        } catch (Exception e){  /* bug */

        } finally{  /* bug */

        }

        /* safe */
        int i = 0;
        if (i==0) {

        } else if (i==1) {

        } else {

        }


        if (i==0){  /* bug */

        } else if (i==1){   /* bug */

        } else{ /* bug */

        }


        if (i==0) {

        }else if (i==1) {   /* bug */

        }else { /* bug */

        }

        /* safe */
        do {

        } while(1);


        do{ /* bug */

        } while(1);


        do {

        }while(1);  /* bug */

    }
}