//MISSING_DEFAULT_IN_SWITCH
package cc;

class MissingDefaultInSwitch {
    public void test(int a, int b){
        switch (a) {   		 	/* Safe */
        case 1:
            switch (b) {    /* Bug */
            case 2:
                //Do something
                break;
            }
            break;
        default:
            //Do something
            break;
        }
        switch (b) {   		 		/* Bug */
        case 1:
            //Do something
            break;
        }

    }
}