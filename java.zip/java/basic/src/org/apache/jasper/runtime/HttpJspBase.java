package org.apache.jasper.runtime;

public class HttpJspBase {

}
