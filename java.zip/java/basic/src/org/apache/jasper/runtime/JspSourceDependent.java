package org.apache.jasper.runtime;

import javax.servlet.http.HttpSession;

public interface JspSourceDependent {
}
