//SECURITY.THREAD.LOCAL.NOT_REINITIALIZED
package cert.tps;

public class TPS04SecurityThreadLocalNotReinitialized {
    enum Day {
        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
    }

    final class TPS04Diary {
        private static final ThreadLocal<Day> days =
                new ThreadLocal<Day>() {
                    // Initialize to Monday
                    protected Day initialValue() {
                        return Day.MONDAY;
                    }
                };

        private static Day currentDay() {
            return days.get();
        }

        public static void setDay(Day newDay) {
            days.set(newDay);
        }

        // Performs some thread-specific task
        public void threadSpecificTask() {
            // Do task ...
        }
    }

    final class TPS04DiaryPool {
        final int numOfThreads = 2; // Maximum number of threads allowed in pool
        final Executor exec;
        final TPS04Diary TPS04Diary;

        TPS04DiaryPool() {
            exec = (Executor) Executors.newFixedThreadPool(numOfThreads);
            TPS04Diary = new TPS04Diary();
        }

        public void doSomething1() {
            exec.execute(new Runnable() { /* BUG */
                @Override public void run() {
                    TPS04Diary.setDay(Day.FRIDAY);
                    TPS04Diary.threadSpecificTask();
                }
            });
        }

        public void foo() {
            TPS04DiaryPool dp = new TPS04DiaryPool();
            dp.doSomething1();
        }
    }

    final class TPS04DiaryPool2 {
        final int numOfThreads = 2; // Maximum number of threads allowed in pool
        final Executor exec;
        final TPS04Diary2 TPS04Diary2;

        TPS04DiaryPool2() {
            exec = (Executor) Executors.newFixedThreadPool(numOfThreads);
            TPS04Diary2 = new TPS04Diary2();
        }

        public void doSomething2() {
            exec.execute(new Runnable() { /* BUG */
                @Override public void run() {
                    TPS04Diary2.threadSpecificTask();
                }
            });
        }

        public void foo2() {
            TPS04DiaryPool2 dp = new TPS04DiaryPool2();
            dp.doSomething2();
        }
    }

    final class TPS04DiaryPool3 {
        final int numOfThreads = 2; // Maximum number of threads allowed in pool
        final Executor exec;
        final TPS04Diary3 TPS04Diary3;

        TPS04DiaryPool3() {
            exec = (Executor) Executors.newFixedThreadPool(numOfThreads);
            TPS04Diary3 = new TPS04Diary3();
        }

        public void doSomething3() {
            exec.execute(new Runnable() { /* BUG */
                @Override public void run() {
                    try {
                        TPS04Diary3.setDay(Day.FRIDAY);
                        TPS04Diary3.threadSpecificTask();
                    } finally {
                        // Do nothing
                    }
                }
            });
        }

        public void foo3() {
            TPS04DiaryPool3 dp = new TPS04DiaryPool3();
            dp.doSomething3();
        }
    }

}
