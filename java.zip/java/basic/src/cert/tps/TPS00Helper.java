//SECURITY.PATTERN.THREAD_PER_MESSAGE
package cert.tps;

class TPS00Helper {
    public void handle(Socket socket) {
        //...
    }
}

final class TPS00RequestHandler {
    private final TPS00Helper TPS00Helper = new TPS00Helper();
    private final ServerSocket server;

    private TPS00RequestHandler(int port) throws IOException {       /* Bug */
        server = new ServerSocket(port);
    }

    public static TPS00RequestHandler newInstance() throws IOException {
        return new TPS00RequestHandler(0); // Selects next available port
    }

    public void handleRequest() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    TPS00Helper.handle(server.accept());
                } catch (IOException e) {
                    // Forward to handler
                }
            }
        }).start();
    }

}