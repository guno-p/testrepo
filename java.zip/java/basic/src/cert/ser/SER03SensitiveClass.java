//SECURITY.SERIALIZABLE.METHOD_OVERRIDE
package cert.ser;

import java.io.Serializable;

public class SER03SensitiveClass extends SER03Number {                            /* Bug */

    private static final SER03SensitiveClass INSTANCE = new SER03SensitiveClass();
    public static SER03SensitiveClass getInstance() {
        return INSTANCE;
    }

    private SER03SensitiveClass() {
        // Perform security checks and parameter validation
    }

    private int balance = 1000;
    protected int getBalance() {
        return balance;
    }
}

class SER03Number implements Serializable {
    // ..
}

public class SER03SensitiveClass2 extends SER03Number2 {                            /* Safe */
    // ...

    private final Object writeObject(java.io.ObjectOutputStream out) throws NotSerializableException {
        throw new NotSerializableException();
    }
    private final Object readObject(java.io.ObjectInputStream in) throws NotSerializableException {
        throw new NotSerializableException();
    }
    private final Object readObjectNoData(java.io.ObjectInputStream in) throws NotSerializableException {
        throw new NotSerializableException();
    }
}

class SER03Number2 implements Serializable {
    // ..
}

public class SER03SensitiveClass3 extends SER03Number3 {                            /* Bug */
    // ...

    private final Object writeObject(java.io.ObjectOutputStream out) throws NotSerializableException {
        throw new NotSerializableException();
    }
    private final Object readObject(java.io.ObjectInputStream in) throws NotSerializableException {
        throw new NotSerializableException();
    }
}

class SER03Number3 implements Serializable {
    // ..
}