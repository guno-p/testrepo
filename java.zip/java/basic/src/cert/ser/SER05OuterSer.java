//SECURITY.INNER_CLASS.SERIALIZABLE
package cert.ser;

public class SER05OuterSer implements Serializable {
    private int rank;
    class SER05InnerSer implements Serializable {    /* Bug */
        protected String name;
        //...
    }
}
