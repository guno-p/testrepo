//SECURITY.SERIALIZABLE.FIELD.TRANSIENT
package cert.ser;

import java.io.Serializable;

public class SER03Point {
    private double x;                   /* Bug */
    private double y;                   /* Bug */

    public SER03Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public SER03Point() {
        // no-argument constructor
    }
}

public class SER03Coordinates extends SER03Point implements Serializable {
    public static void main(String[] args) {
        FileOutputStream fout = null;
        try {
            SER03Point p = new SER03Point(5, 2);
            fout = new FileOutputStream("SER03Point.ser");
            ObjectOutputStream oout = new ObjectOutputStream(fout);
            oout.writeObject(p);
        } catch (Throwable t) {
            // Forward to handler
        } finally {
            if (fout != null) {
                try {
                    fout.close();
                } catch (IOException x) {
                    // handle error
                }
            }
        }
    }
}


public class SER03Point2 {
    private transient double x;                         /* Safe */
    private transient double y;                         /* Safe */

    public SER03Point2(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public SER03Point2() {
        // no-argument constructor
    }
}

public class SER03Coordinates2 extends SER03Point2 implements Serializable {
    public static void main(String[] args) {
        FileOutputStream fout = null;
        try {
            SER03Point2 p = new SER03Point2(5,2);
            fout = new FileOutputStream("SER03Point.ser");
            ObjectOutputStream oout = new ObjectOutputStream(fout);
            oout.writeObject(p);
            oout.close();
        } catch (Exception e) {
            // Forward to handler
        } finally {
            if (fout != null) {
                try {
                    fout.close();
                } catch (IOException x) {
                    // handle error
                }
            }
        }
    }
}