//SECURITY.CALL.PUBLIC_METHOD
package cert.ser;

public class SER09FordiddenCallPublicMethod{

    private void readObject(final ObjectInputStream stream)
            throws IOException, ClassNotFoundException {
                SER09AnotherClass anotherClass = new SER09AnotherClass();
        String a;

        overridableMethod();                            /* Bug */

        nonOverridableMethod();                         /* Safe */

        anotherClass.overridableMethodInAnotherClass(); /* Bug */

        nonOverridableMethod(a);                        /* Safe */

        stream.defaultReadObject();

        anotherClass.overridableMethodInAnotherClass(); /* Safe */
    }

    public void overridableMethod() {
        // ...
    }

    public final void nonOverridableMethod(){
        // ...
    }

    private void nonOverridableMethod(String a){
        // ...
    }
}

public class SER09AnotherClass{
    public void overridableMethodInAnotherClass(){
        // ...
    }
}