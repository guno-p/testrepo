package cert.thi;

import javax.servlet.http.HttpServlet;

public class THI06 extends HttpServlet { 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException {
        Runnable r = new Runnable() {
            public void run() { 
                System.err.println("do something"); 
            }
        };
        new Thread(r).start(); 
    } 
}