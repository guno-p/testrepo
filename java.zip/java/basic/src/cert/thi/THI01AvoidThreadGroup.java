//AvoidThreadGroup
package cert.thi;

public class THI01AvoidThreadGroup {
	void buz() {
		ThreadGroup tg = new ThreadGroup("My threadgroup");
		tg = new ThreadGroup(tg, "my thread group");
		tg = Thread.currentThread().getThreadGroup();
		tg = System.getSecurityManager().getThreadGroup();
	}
}   