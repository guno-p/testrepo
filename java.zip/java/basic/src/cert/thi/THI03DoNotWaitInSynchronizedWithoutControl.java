//DO_NOT_WAIT_IN_SYNCHRONIZED_WITHOUT_CONTROL
package cert.thi;

import java.util.concurrent.locks.Lock;

public class THI03DoNotWaitInSynchronizedWithoutControl {
 public void badWait() {
        Lock lock;
        boolean condition;
        // Do something ...

        synchronized(lock) {
            lock.wait(); /* BUG */
        }

        while(condition) {
            synchronized (lock) {
                lock.wait(); /* BUG */
            }
        }
    }

    public void goodWait(int k) {
        Lock lock;
        boolean condition;
        // Do something ...

        synchronized(lock) {
            if(condition) {
                lock.wait(); /* SAFE */
                // Do something ...
            }

            if(!condition) {
                // Do something ...
            } else {
                lock.wait(); /* SAFE */
            }

            while(condition) {
                lock.wait(); /* SAFE */
                // Do something ...
            }

            for(int i=0; i<10; i++) {
                lock.wait(); /* SAFE */
                // Do something ...
            }

            do {
                lock.wait(); /* SAFE */
                // Do something ...
            } while(condition);

            switch (k) {
            case 0:
                lock.wait(); /* SAFE */
                break;
                // Do something ...
            default:
                break;
            }
        }
    }
}