//SECURITY.SYNCHRONIZE.ORDER
package cert.lck;

final class LCK07SecuritySynchronizeOrder {
    private double balanceAmount;  // Total amount in bank account

    LCK07SecuritySynchronizeOrder(double balance) {
        this.balanceAmount = balance;
    }

    // Deposits the amount from this object instance
    // to BankAccount instance argument ba
    private void depositAmount(LCK07SecuritySynchronizeOrder ba, double amount) {
        synchronized (this) {                       /* Bug */
            synchronized (ba) {
                if (amount > balanceAmount) {
                    throw new IllegalArgumentException(
                            "Transfer cannot be completed"
                    );
                }
                ba.balanceAmount += amount;
                this.balanceAmount -= amount;
            }
        }

        synchronized (ba) {                         /* Bug */
            synchronized (this) {
                if (amount > balanceAmount) {
                    throw new IllegalArgumentException(
                            "Transfer cannot be completed"
                    );
                }
                ba.balanceAmount += amount;
                this.balanceAmount -= amount;
            }
        }
    }

    @Override
    public int compareTo(BankAccount ba) {
        return (this.id > ba.id) ? 1 : (this.id < ba.id) ? -1 : 0;
    }

    private void depositAmount_Good(LCK07SecuritySynchronizeOrder ba, double amount) {
        BankAccount former, latter;
        if (compareTo(ba) < 0) {
            former = this;
            latter = ba;
        } else {
            former = ba;
            latter = this;
        }
        synchronized (former) {                     /* Safe */
            synchronized (latter) {
                if (amount > balanceAmount) {
                    throw new IllegalArgumentException(
                            "Transfer cannot be completed");
                }
                ba.balanceAmount += amount;
                this.balanceAmount -= amount;
            }
        }
    }

    public static void initiateTransfer(final LCK07SecuritySynchronizeOrder first,
                                        final LCK07SecuritySynchronizeOrder second, final double amount) {

        Thread transfer = new Thread(new Runnable() {
            public void run() {
                first.depositAmount(second, amount);
            }
        });
        transfer.start();
    }
}