//SECURITY.SYNCHRONIZE.BACK_COLLECTION
package cert.lck;
import java.util.Set;

public class LCK04MisuseSynchronizeBackCollection{
    private final Map<Integer, String> mapView =
            Collections.synchronizedMap(new HashMap<Integer, String>());
    private final Set<Integer> setView = new Set<Integer>();

    public LCK04MisuseSynchronizeBackCollection(){
        setView = mapView.keySet();
    }

    public Map<Integer, String> getMap() {
        return mapView;
    }

    public void doSomething() {
        synchronized (setView) {                                    /* Bug */
            for (Integer k : setView) {
                // ...
            }
        }

        synchronized (mapView) {                                    /* Safe */
            for (Integer k : setView) {
                // ...
            }
        }
    }
}