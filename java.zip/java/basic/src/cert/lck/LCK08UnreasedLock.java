//UNRELEASED_LOCK
package cert.lck;

public class LCK08UnreasedLock{
	final Lock mutex; 
	private int numOne = 0;
	public UseLock ()  {
		this.mutex = new ReentrantLock(); 
	}
	public void add(int numTwo) throws InterruptedException {
		this.mutex.lock(); // Should use unlock 
		numOne += numTwo;
	}
}