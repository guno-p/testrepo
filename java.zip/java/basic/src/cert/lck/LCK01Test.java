//SECURITY.SYNCHRONIZE.REUSABLE_OBJECT
package cert.lck;

public class LCK01Test{

    private final Boolean initialized = Boolean.FALSE;

    public void doSomething() {
        synchronized (initialized) {            /* Bug */
            // ...
        }
    }

    int lock = 0;
    private final Integer Lock = lock; // Boxed primitive Lock is shared

    public void doSomething() {
        synchronized (Lock) {                   /* Bug */
            // ...
        }
    }

    private final String lock = new String("LOCK").intern();

    public void doSomething() {
        synchronized (lock) {                   /* Bug */
            // ...
        }
    }

    private final String locked = new String("LOCK");     /* Safe */

    public void doSomething() {
        synchronized (locked) {
            // ...
        }
    }


    // This bug was found in jetty-6.1.3 BoundedThreadPool
    private final String lockLiteral = "LOCK";

    public void doSomething() {
        synchronized (lockLiteral) {                        /* Bug */
            // ...
        }
    }
}