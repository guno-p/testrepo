//SECURITY.SYNCHRONIZE.LOCK_OR_CONDITION
package cert.lck;

import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.AbstractQueuedLongSynchronizer.ConditionObject;

public class LCK03Test{
    private final Lock lock = new ReentrantLock();
    private final Lock lock_condition = new ConditionObject();

    public void doSomething() {
        synchronized(lock) {            /* Bug */
            // ...
        }

        synchronized(lock_condition) {            /* Bug */
            // ...
        }

        lock.lock();                /* Safe */
        try {
            // ...
        } finally {
            lock.unlock();
        }
    }
}
