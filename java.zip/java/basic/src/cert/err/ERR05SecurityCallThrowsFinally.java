//SECURITY.CALL.THROWS.FINALLY
package cert.err;

public class ERR05SecurityCallThrowsFinally {
    public static void doOperation(String some_file) {
        // ... code to check or set character encoding ...
        try {
            BufferedReader reader =
                    new BufferedReader(new FileReader(some_file));
            try {
                // Do operations
            } finally {
                reader.close();                         /* Bug */
                // ... Other cleanup code ...
            }
        } catch (IOException x) {
            // Forward to handler
        }
    }
}

class BufferedReader{
    public BufferedReader(FileReader reader){}

    public void close() throws IOException {
        // ...
    }
}