//SECURITY.INTER_CLASS_CYCLE
package cert.dcl;

class DCL00A {
    public static final int a = DCL00B.b + 1;    /* Bug */
}

class DCL00B {
    public static final int b = DCL00C.c + 1;    /* Bug */
    // ...
}

class DCL00C {
    public static final int c = DCL00A.a + 1;    /* Bug */
    // ...
}