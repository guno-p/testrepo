package cert.dcl;

import java.sql.DriverManager;
import javax.servlet.http.HttpServlet;

public class DCL04 extends HttpServlet {
    private Connection conn;
    public void dbConnection(String url, String user, String pw) {
        try {
            conn = DriverManager.getConnection(url, user, pw);  /* BUG */
        } catch (SQLException e) {
            System.err.println("...");
        } finally {
            //...
        }
    }
}