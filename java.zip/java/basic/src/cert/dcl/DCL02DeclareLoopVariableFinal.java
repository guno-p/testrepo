//SECURITY.LOOP_VARIABLE_FINAL
package cert.dcl;

public class DCL02DeclareLoopVariableFinal{
    public void getTest(){
        for(String str : list){        /* Bug */

        }
    }
}