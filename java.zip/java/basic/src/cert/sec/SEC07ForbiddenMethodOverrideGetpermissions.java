//SECURITY.METHOD.OVERRIDE.GETPERMISSIONS
package cert.sec;

import java.net.URLClassLoader;

public class SEC07ForbiddenMethodOverrideGetpermissions extends URLClassLoader {
    protected PermissionCollection getPermissions(CodeSource cs) {
        PermissionCollection pc = new Permissions();                    /* Bug */
        // allow exit from the VM anytime
        pc.add(new RuntimePermission("exitVM"));
        return pc;
    }
}
