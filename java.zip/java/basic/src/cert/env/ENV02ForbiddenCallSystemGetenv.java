//SECURITY.CALL.SYSTEM_GETENV
package cert.env;

public class ENV02ForbiddenCallSystemGetenv {
    private String name;

    public ENV02ForbiddenCallSystemGetenv(){
        this.name = System.getenv("USER");            /* Bug */
    }

    public void test(){
        String username = System.getenv("USER");            /* Bug */
    }
}