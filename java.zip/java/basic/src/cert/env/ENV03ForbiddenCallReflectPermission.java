//SECURITY.CALL.REFLECT_PERMISSION
package cert.env;

public class ENV03ForbiddenCallReflectPermission {
    protected PermissionCollection getPermissions(CodeSource cs) {
        PermissionCollection pc = super.getPermissions(cs);
        ReflectPermission reflect = new ReflectPermission("suppressAccessChecks");

        pc.add(new ReflectPermission("suppressAccessChecks"));              /* Bug */
        pc.add(reflect);                                                    /* Bug */

        return pc;
    }
}