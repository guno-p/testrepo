package cert.env;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.*;

public class ENV0405 {
    public static void main(String[] args) { 
        RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
        List<String> jvmArgs = runtimeMXBean.getInputArguments();
        for (String arg : jvmArgs) {
            if(arg.equals("-Xverify:none") || arg.equals("-novertify")) {
                System.out.println("SECURITY.DISABLE.BYTECODE_VERIFICATION");
                System.out.println(arg);
            } else if (arg.equals("-agentlib") ||
            arg.equals("-Xrunjdwp") ||
            arg.equals("-Xdebug") ||
            arg.equals("-agentpath") ||
            arg.equals("-Dcom.sun.management.jmxremote.port")) {
                System.out.println("SECURITY.DEPLOY.REMOTELY_MONITORING");
                System.out.println(arg);
            }
            
        }
    }

}