//AvoidDecimalLiteralsInBigDecimalConstructor
package cert.num;

public class NUM10AvoidDecimalLiteralsInBigDecimalConstructor {
	public static void main(String[] args) {
		BigDecimal bd = new BigDecimal(1.123);       /* BUG */

		BigDecimal bd2 = new BigDecimal("1.123");     

		BigDecimal bd3 = new BigDecimal(12);  
	}
}