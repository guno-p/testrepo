//SECURITY.CAST.FLOAT_DOUBLE
package cert.num;

class NUM13WideSample {
    static int subFloatFromInt(int op1, float op2) {
        return op1 - (int) op2; /* BUG */
    }
}