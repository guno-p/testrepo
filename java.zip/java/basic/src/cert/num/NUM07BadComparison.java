//BadComparison
package cert.num;

public class NUM07BadComparison {
	public static void main(String[] args) {
		double y = 0.0;
		boolean x = (y == Double.NaN);  /* BUG */
	}
}