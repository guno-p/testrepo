//SECURITY.RETURN.INTEGER_DATA
package cert.num;

import java.io.DataInputStream.*;

class NUM03SecurityReturnIntegerData{
    public static long getInteger(DataInputStream is) throws IOException {

        int int_var = 0;
        long long_var = 0;

        long_var = is.readInt();                /* Bug */
        long_var = is.readInt() & 0xFFFFFFFFL;  /* Safe */
        int_var = is.readInt();                 /* Safe */

        boolean flag = true;

        if(flag){
            return is.readInt();                /* Bug */
        } else {
            return is.readInt() & 0xFFFFFFFFL;  /* Safe */
        }

    }
}