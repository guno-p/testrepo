//SECURITY.CALL.APPEND.LOOP
package cert.msc;

public class MSC05ReadNames {
    private Vector<String> names = new Vector<String>();
    private final InputStreamReader input;
    private final BufferedReader reader;

    public MSC05ReadNames(String filename) throws IOException {
        this.input = new FileReader(filename);
        this.reader = new BufferedReader(input);
    }

    public void addNames() throws IOException {
        try {
            String newName;
            while (((newName = reader.readLine()) != null) &&		/* Bug */
                    !(newName.equalsIgnoreCase("quit"))) {
                names.addElement(newName);                          /* Bug */
                System.out.println("adding " + newName);
            }
        } finally {
            input.close();
        }
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 1) {
            System.out.println("Arguments: [filename]");
            return;
        }
        MSC05ReadNames demo = new MSC05ReadNames(args[0]);
        demo.addNames();
    }
}