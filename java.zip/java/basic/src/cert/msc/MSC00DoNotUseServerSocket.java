package cert;

import java.net.ServerSocket;
import java.net.Socket;
// Exception handling has been omitted for the sake of brevity
class MSC00DoNotUseServerSocket {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;   /* BUG */
        try {
            serverSocket = new ServerSocket(9999);
            Socket socket = serverSocket.accept();   /* BUG */
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println(inputLine);
                out.println(inputLine);
            }
        } finally {
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException x) {
                    // Handle error
                }
            }
        }
    }
}