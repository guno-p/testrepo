//SECURITY.CALL.REMOVE.LOOP
package cert.msc;

import java.util.Iterator;

class MSC06BadIterate {
    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");

        Iterator iter = list.iterator();
        while (iter.hasNext()) {
            String s = (String)iter.next();
            if (s.equals("one")) {
                list.remove(s);                         /* Bug */
                iter.remove(s);                         /* Safe */
            }
        }

        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            String s = (String)iter.next();
            if (s.equals("one")) {
                list.remove(s);                         /* Bug */
                iterator.remove(s);                     /* Safe */
            }
        }
    }
}