package cert.msc;

public class MSC11 implements InterestRateRemote {
    private Document interestRateXMLDocument = null; 
    private File interestRateFile = null; 
    public InterestRateBean() { 
        try { /* get XML document from the local filesystem */ 
            interestRateFile = new File(Constants.INTEREST_RATE_FILE); 
            if (interestRateFile.exists()) { 
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance(); 
                DocumentBuilder db = dbf.newDocumentBuilder(); 
                interestRateXMLDocument = db.parse(interestRateFile); 
            } 
        } catch (IOException ex) {
            //...
        } 
    } 
    public BigDecimal getInterestRate(Integer points) { 
        return getInterestRateFromXML(points); 
    }
    private BigDecimal getInterestRateFromXML(Integer points) {
        //...
    }
}

