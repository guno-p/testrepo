package cert.vna;

public class VNA05 {
    private int ID;
    public void setID(int ID){ 
        synchronized(this){ 
            
        } 
        this.ID = ID;
    }
}