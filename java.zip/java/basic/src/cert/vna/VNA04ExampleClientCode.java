//SECURITY.PATTERN.METHOD_CHAINING
package cert.vna;

class VNA04ExampleClientCode {
    private int quarters = 0;
    private int dimes = 0;
    private int nickels = 0;
    private int pennies = 0;

    private final VNA04ExampleClientCode currency = new VNA04ExampleClientCode();
    private volatile VNA04ExampleClientCode currency2 = new VNA04ExampleClientCode();

    public VNA04ExampleClientCode() {

        Thread t1 = new Thread(new Runnable() {
            @Override public void run() {
                currency.setQuarters(1).setDimes(1);        /* Bug */
                currency2 = VNA04ExampleClientCode.setQuarters(1).setDimes(1).build();
            }
        });
        t1.start();

        Thread t2 = new Thread(new Runnable() {
            @Override public void run() {
                currency.setQuarters(2).setDimes(2);        /* Bug */
                currency2 = VNA04ExampleClientCode.setQuarters(2).setDimes(2).build();
            }
        });
        t2.start();

        //...
    }

    public VNA04ExampleClientCode setQuarters(int quantity) {
        this.quarters = quantity;
        return this;
    }
    public VNA04ExampleClientCode setDimes(int quantity) {
        this.dimes = quantity;
        return this;
    }
    public VNA04ExampleClientCode setNickels(int quantity) {
        this.nickels = quantity;
        return this;
    }
    public VNA04ExampleClientCode setPennies(int quantity) {
        this.pennies = quantity;
        return this;
    }


}