//SECURITY.THREAD.SHARED_VARIABLE
package cert.vna;

import java.lang.Boolean;
import java.lang.Runnable;

final class VNA00ControlledStop implements Runnable {
    private boolean done = false;                   /* Bug */
    private Boolean Done = false;                   /* Bug */
    private volatile boolean flag = false;                   /* Safe */
    private volatile Boolean Flag = false;                   /* Safe */

    @Override public void run() {
        while (!done) {
            try {
                // ...
                Thread.currentThread().sleep(1000); // Do something
            } catch(InterruptedException ie) {
                Thread.currentThread().interrupt(); // Reset interrupted status
            }
        }

        while (!Done) {
            try {
                // ...
                Thread.currentThread().sleep(1000); // Do something
            } catch(InterruptedException ie) {
                Thread.currentThread().interrupt(); // Reset interrupted status
            }
        }

        while (!flag) {
            try {
                // ...
                Thread.currentThread().sleep(1000); // Do something
            } catch(InterruptedException ie) {
                Thread.currentThread().interrupt(); // Reset interrupted status
            }
        }

        while (!Flag) {
            try {
                // ...
                Thread.currentThread().sleep(1000); // Do something
            } catch(InterruptedException ie) {
                Thread.currentThread().interrupt(); // Reset interrupted status
            }
        }
    }

    public void shutdown() {
        done = true;
        Done = true;
    }
}