//SECURITY.METHOD.OVERRIDE.STATIC
package cert.met;

class MET07GrantAccess {
    public static void displayAccountStatus() {                 /* Bug */
        System.out.println("Account details for admin: XX");
    }
}

class MET07GrantUserAccess extends MET07GrantAccess {
    public static void displayAccountStatus() {                 /* Bug */
        System.out.println("Account details for user: XX");
    }
}

public class MET07StatMethod {
    public static void choose(String username) {
        MET07GrantAccess admin = new MET07GrantAccess();
        MET07GrantAccess user = new MET07GrantUserAccess();
        if (username.equals("admin")) {
            admin.displayAccountStatus();               /* Call static method */
        } else {
            user.displayAccountStatus();                /* Call static method */
        }
    }

    public static void main(String[] args) {
        choose("user");
    }
}

class MET07GrantAccess2 {
    public static void displayAccountStatus() {                 /* Safe */
        System.out.println("Account details for admin: XX");
    }
}

class MET07GrantUserAccess2 extends MET07GrantAccess2 {
    public static void displayAccountStatus() {                 /* Safe */
        System.out.println("Account details for user: XX");
    }
}

public class MET07StatMethod2 {
    public static void choose(String username) {
        if (username.equals("admin")) {
            MET07GrantAccess2.displayAccountStatus();                 /* Call static method but safe */
        } else {
            MET07GrantUserAccess2.displayAccountStatus();             /* Call static method but safe */
        }
    }

    public static void main(String[] args) {
        choose("user");
    }
}