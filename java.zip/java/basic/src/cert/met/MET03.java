//SECURITY.METHOD.OVERRIDE
package cert.met;

public class MET03 {
    public void readSensitiveFile() {   /* BUG */
        try {
            SecurityManager sm = System.getSecurityManager();
            if (sm != null) {
                sm.checkRead("/temp/tempFile");
            }
        } catch (SecurityException se) {
        }
    }
}