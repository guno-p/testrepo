//SECURITY.METHOD.PROTECTED
package cert.met;

class MET04Super {
    protected void doLogic() {                  /* Bug */
        System.out.println("Super invoked");
    }

    protected final void doLogicExam() {                  /* Safe */
        System.out.println("Super invoked");
    }
}

public class MET04Sub extends MET04Super {
    public void doLogic() {
        System.out.println("Sub invoked");
        // Do sensitive operations
    }
}