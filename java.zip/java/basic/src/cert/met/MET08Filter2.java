//SECURITY.CALL.URL_EQUALS
package cert.met;

public class MET08Filter2 {
    public static void main(String[] args) throws MalformedURLException {
        final URL allowed = new URL("http://mailwebsite.com");
        if (!allowed.equals(new URL(args[0]))) {                /* Bug */
            throw new SecurityException("Access Denied");
        }
        // Else proceed
    }
}