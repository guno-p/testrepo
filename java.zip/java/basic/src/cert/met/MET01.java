//SECURITY.ARGUMENT.ASSERT
package cert.met;

public class MET01 {
    public static int getAbsAdd(int x, int y) {
        assert x != Integer.MIN_VALUE;              /* Bug */
        assert y != Integer.MIN_VALUE;              /* Bug */
        int absX = Math.abs(x);
        int absY = Math.abs(y);
        assert (absX <= Integer.MAX_VALUE - absY);
        return absX + absY;
    }
}