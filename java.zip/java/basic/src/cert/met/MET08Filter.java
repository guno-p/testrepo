//SECURITY.CALL.KEY_EQUALS
package cert.met;


public class MET08Filter {
    private static boolean keysEqual(Key key1, Key key2) {
        if (key1.equals(key2)) {            /* Bug */
            return true;
        }
        return false;
    }
}
