package cert.met;

public class MET18 {
    class BaseClass { 
        @Override 
        public Object clone() throws CloneNotSupportedException { 
            return new BaseClass(); 
        } 
    } 
    class DerivedClass extends BaseClass implements Cloneable {
        public void sayHello() { 
            System.out.println("Hello, world!"); 
        } 
    }

    public static void main(String[] args) throws Exception { 
        DerivedClass instance = new DerivedClass(); 
        ((DerivedClass) instance.clone()).sayHello();         
    } 
    
}