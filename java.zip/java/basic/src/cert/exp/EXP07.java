package cert.exp;

public class EXP07 {

    private String[] colors;
    public String[] getColors() { 
        return colors; 
    }
}