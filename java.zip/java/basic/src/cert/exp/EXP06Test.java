//SECURITY.ASSERT.BOOLEAN
package cert.exp;

public class EXP06Test{

    private ArrayList<String> names;

    void process(int index) {
        assert names.remove(null);      /* Bug */
        assert index++;                 /* Bug */
        assert index = 2;               /* Bug */
        assert ++index;                 /* Bug */
        assert names.remove(index++);   /* Bug */
        // ...
    }

    void proces2(int index) {
        boolean nullsRemoved = names.remove(null);
        assert nullsRemoved;            /* Safe */
        // ...
    }
}