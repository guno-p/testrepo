package cert.exp;

public class EXP08 {

    private String[] userRoles;
    public void setUserRoles(String[] userRoles) {
        this.userRoles = userRoles;
    }
}