//BAD_COLLECTION_REMOVAL.INTEGER_TYPE
package cert.exp;

public class EXP04BadCollectionRemovalIntegerType {
	public void badFunc() {
		HashSet set = new HashSet();
		short s = 10;
		set.add(s);
		set.remove(s -1);
	}
}