//SECURITY.PUBLISH_BEFORE_INITIALIZATION
package cert.tsm;

final class TSM01Publisher {
    public static TSM01Publisher published;
    public static volatile TSM01Publisher published2;
    int num;
    String str;

    TSM01Publisher(int number, String str) {
        // Initialization
        this.num = number;
        // ...
        published = this;

        published2 = this;
        // Initialization
        this.str = str;                             /* Bug */
    }
}