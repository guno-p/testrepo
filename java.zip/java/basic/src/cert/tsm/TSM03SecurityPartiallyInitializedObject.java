//SECURITY.PARTIALLY_INITIALIZED_OBJECT
package cert.tsm;

public class TSM03SecurityPartiallyInitializedObject {
    public class TSM03Helper {
        private int n;

        public TSM03Helper(int n) {
            this.n = n;
        }
        // ...
    }

    class TSM03DangerousFoo {
        private TSM03Helper TSM03Helper;

        public TSM03Helper TSM03getHelper() {
            return TSM03Helper;
        }

        public void initialize() { // @violation
            TSM03Helper = new TSM03Helper(42);
        }
    }

    class TSM03SafeFoo1 { // Safe since it uses synchronized methods
        private TSM03Helper TSM03Helper;

        public synchronized TSM03Helper TSM03getHelper() {
            return TSM03Helper;
        }

        public synchronized void initialize() {
            TSM03Helper = new TSM03Helper(42);
        }
    }

    class TSM03SafeFoo2 { // Safe since it uses final fields
        private final TSM03Helper TSM03Helper;

        public TSM03Helper TSM03getHelper() {
            return TSM03Helper;
        }

        public Foo() {
            // Point 1
            TSM03Helper = new TSM03Helper(42);
            // Point 2
        }
    }

    class TSM03SafeFoo3 { // Safe since it uses final fields
        private final Vector<TSM03Helper> TSM03Helper;

        public Foo() {
            TSM03Helper = new Vector<TSM03Helper>();
        }

        public TSM03Helper TSM03getHelper() {
            if (TSM03Helper.isEmpty()) {
                initialize();
            }
            return TSM03Helper.elementAt(0);
        }

        public synchronized void initialize() {
            if (TSM03Helper.isEmpty()) {
                TSM03Helper.add(new TSM03Helper(42));
            }
        }
    }

    // Immutable Foo
    final class TSM03SafeFoo4 {
        private static final TSM03Helper TSM03Helper = new TSM03Helper(42);

        public static TSM03Helper TSM03getHelper() {
            return TSM03Helper;
        }
    }

    class TSM03SafeFoo5 {
        private volatile TSM03SafeHelper1 TSM03Helper;

        public TSM03SafeHelper1 TSM03getHelper() {
            return TSM03Helper;
        }

        public void initialize() {
            TSM03Helper = new TSM03SafeHelper1(42);
        }
    }

    // Immutable TSM03Helper
    public final class TSM03SafeHelper1 {
        private final int n;

        public TSM03SafeHelper1(int n) {
            this.n = n;
        }
        // ...
    }

    class TSM03SafeFoo6 {
        private volatile TSM03SafeHelper2 TSM03Helper;

        public TSM03SafeHelper2 TSM03getHelper() {
            return TSM03Helper;
        }

        public void initialize() {
            TSM03Helper = new TSM03SafeHelper2(42);
        }
    }

    // Mutable but thread-safe TSM03Helper
    public class TSM03SafeHelper2 {
        private volatile int n;
        private final Object lock = new Object();

        public TSM03SafeHelper2(int n) {
            this.n = n;
        }

        public void setN(int value) {
            synchronized (lock) {
                n = value;
            }
        }
    }
}