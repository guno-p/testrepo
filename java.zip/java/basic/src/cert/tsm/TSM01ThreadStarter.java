//SECURITY.CALL.THREAD_START
package cert.tsm;

final class TSM01ThreadStarter implements Runnable {
    public TSM01ThreadStarter() {
        Thread thread = new Thread(this);
        thread.start();                         /* Bug */
    }

    @Override public void run() {
        // ...
    }

    public void runThreadGood(){
        Thread thread = new Thread(this);
        thread.start();                         /* Safe */
    }
}