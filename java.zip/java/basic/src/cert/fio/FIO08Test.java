//SECURITY.RETURN.INPUTSTREAM_READ
package cert.fio;

public class FIO08Test {
    public void FIO08Test() {
        FileInputStreamReader in;
        // initialize stream
        byte data;
        while ((data = (byte) in.read()) != -1) {           /* Bug */
            // ...
        }
    }

    public void FIO08Test2() {
        FileInputStream in;
        // initialize stream
        int inbuff;
        byte data;
        while ((inbuff = in.read()) != -1) {                /* Safe */
            data = (byte) inbuff;
            // ...
        }
    }

    public void FIO08Test3() {
        FileReader in;
        // initialize stream
        char data;
        while ((data = (char) in.read()) != -1) {           /* Bug */
            // ...
        }
    }

    public void FIO08Test4() {
        FileReader in;
        // initialize stream
        int inbuff;
        char data;
        while ((inbuff = in.read()) != -1) {                /* Safe */
            data = (char) inbuff;
            // ...
        }
    }

    public void FIO08Test5() {
        FileReader in;
        // initialize stream
        int inbuff;
        char data;
        while (((inbuff = in.read()) != -1) && ((data = (char) in.read()) != -1)) {                /* bug */
            data = (char) inbuff;
            // ...
        }

        while (((inbuff = in.read())) && ((data = (char) in.read()) != 2)) {                /* Safe */
            data = (char) inbuff;
            // ...
        }
    }
}