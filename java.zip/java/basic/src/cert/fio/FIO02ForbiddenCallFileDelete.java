//SECURITY.CALL.FILE_DELETE
package cert.fio;

public class FIO02ForbiddenCallFileDelete {
    public void test() {
        File file = new File("file");
        file.delete();                      /* Bug */
        if (file.delete() == 0) {               /* Safe */
            System.out.println("Deletion failed");
        }

        if(condition) {
            file.delete();                  /* Bug */
        }
    }
}