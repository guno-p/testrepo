
public class StrTest {
    public void foo() {
        String account = "123-12-123456"; // Bad
        String credit_card = "1234-1234-1234-1234"; // Bad
        String driver_lic = "서울-12-123456-12"; // Bad
        String email = "aaa@gmail.com"; // Bad
        String foreigner_id = "110101-5111171";
        String national_id = "110101-3456789"; // Bad
        String phone = "02)123-1234"; // Bad
        String ip = "127.0.0.1"; // Bad
        String passport = "AB1234567"; // Bad
    }
}

