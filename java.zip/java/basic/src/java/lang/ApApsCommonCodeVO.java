package java.lang;

public class ApApsCommonCodeVO {

    public String getTarget() {
        return "";
    }

}
