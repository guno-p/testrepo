
public final class NULL_USR {

    public static final void main(String[] ar) {
        System.out.println(new UsrLib().getString().length());
    }

}

