package com.fasoo.sem.TI.helper;

/**
 * Writer: Gyuhang Shim
 * Date: 4/16/12
 */
public class Contact {
}
