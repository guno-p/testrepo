package com.fasoo.sem.TI;

import java.io.File;
import java.io.RandomAccessFile;
import java.io.FileNotFoundException;

class DO_NOT_BASE_SECURITY_CHECKS_ON_UNTRUSTED_SOURCES_TestCase {
    RandomAccessFile test(File f) throws FileNotFoundException {
        return new RandomAccessFile(f, f.getPath()); /* BUG */
    }
    RandomAccessFile testSafe(File f) throws FileNotFoundException {
        final File copy = new File(f.getPath());
        return new RandomAccessFile(copy, copy.getPath());
    }
}