package com.fasoo.sem;

import javax.servlet.http.*;
import java.util.StringTokenizer;
import java.net.URLDecoder;
import java.io.*;

public class TrustBoundaryViolation_TestCase {
    public void test(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] theCookies = request.getCookies();
        String param = "";
        if (theCookies != null) {
            for (Cookie theCookie: theCookies) {
                if (theCookie.getName().equals("danger")) {
                    param = URLDecoder.decode(theCookie.getValue(), "UTF-8");
                    break;
                }
            }
        }
		request.getSession().setAttribute(param, "danger param"); //Bad
    }

    public void test2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        javax.servlet.http.Cookie[] theCookies = request.getCookies();
        String param = "";
        if (theCookies != null) {
            for (javax.servlet.http.Cookie theCookie : theCookies) {
                if (theCookie.getName().equals("danger")) {
                    param = java.net.URLDecoder.decode(theCookie.getValue(), "UTF-8");
                    break;
                }
            }
        }
        if(isSafe(param)) {
            request.getSession().setAttribute( param, "danger param"); //Good
        } else {
            //
        }
    }
}
