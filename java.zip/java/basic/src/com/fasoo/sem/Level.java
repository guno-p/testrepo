package com.fasoo.sem;
/**
 * Created with IntelliJ IDEA.
 * User: starblood
 * Date: 12. 11. 22.
 * Time: 오후 1:55
 * To change this template use File | Settings | File Templates.
 */
public class Level {
    public static final int WARNING = 0;
}
