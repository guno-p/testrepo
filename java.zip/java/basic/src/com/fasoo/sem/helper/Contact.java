package com.fasoo.sem.helper;

/**
 * Writer: 
 * Date: 4/16/12
 */
public class Contact {
}
