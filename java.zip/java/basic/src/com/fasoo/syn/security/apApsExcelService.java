package com.fasoo.syn.security;

import java.util.List;

public class apApsExcelService {

    public static List selectCommonCode(ApApsCommonCodeVO apApsCommonCodeVO) {
        return (List)new Object();
    }

}
