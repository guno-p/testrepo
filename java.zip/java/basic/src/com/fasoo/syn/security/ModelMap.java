package com.fasoo.syn.security;

public class ModelMap {

}
